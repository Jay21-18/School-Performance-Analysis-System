def add_student(students, student_id, name, math, science, english):
    students[student_id] = {
        "name": name,
        "marks": {
            "math": math,
            "science": science,
            "english": english,
        },
    }


def calculate_average(grades):
    """
    Calculate the average marks from the grades dictionary.
    :param grades: Dictionary containing subject marks
    :return: Average of the marks
    """
    return sum(grades.values()) / len(grades)


def identify_pass_fail(students, passing_marks=50):
    """
    Identify students who passed or failed based on their marks.
    :param students: Dictionary of student records
    :param passing_marks: Minimum marks required to pass
    :return: Dictionary with lists of passed and failed students
    """
    passed = []
    failed = []
    for student_id, student_data in students.items():
        marks = student_data["marks"].values()  # Access only the marks
        if all(mark >= passing_marks for mark in marks):
            passed.append(student_data["name"])
        else:
            failed.append(student_data["name"])
    return {"passed": passed, "failed": failed}


def find_top_performer(students):
    """
    Find the top performer based on average marks.
    :param students: Dictionary of student records
    :return: Name of the top performer
    """
    top_student = None
    highest_average = 0
    for student_id, student_data in students.items():
        marks = student_data["marks"]  # Access only the marks
        average = calculate_average(marks)
        if average > highest_average:
            highest_average = average
            top_student = student_data["name"]
    return top_student


def display_students(students):
    """
    Display all student records in alphabetical order.
    :param students: Dictionary of student records
    """
    for student_id in sorted(students.keys()):
        student_data = students[student_id]
        marks = student_data["marks"]  # Access only the marks
        average = calculate_average(marks)
        print(
            f"{student_id}: Name: {student_data['name']}, Grades: {marks}, Average: {average:.2f}"
        )
