def display_menu():
    print("School Performance Analysis System")
    print("1. Add Student")
    print("2. Calculate Average Marks")
    print("3. Identify Pass/Fail Students")
    print("4. Find Top Performer")
    print("5. Display All Students")
    print("6. Exit")


def main():
    from student_operations import (
        add_student,
        calculate_average,
        identify_pass_fail,
        find_top_performer,
        display_students,
    )

    students = {}

    while True:
        display_menu()
        choice = input("Enter your choice: ")

        if choice == "1":
            student_id = input("Enter student ID: ")
            name = input("Enter student name: ")
            math = float(input("Enter Math marks: "))
            science = float(input("Enter Science marks: "))
            english = float(input("Enter English marks: "))
            add_student(students, student_id, name, math, science, english)

        elif choice == "2":
            student_id = input("Enter student ID to calculate average: ")
            if student_id in students:
                grades = students[student_id]["marks"]
                average = calculate_average(grades)
                print(f"Average marks for {student_id}: {average}")
            else:
                print(f"Student ID {student_id} not found.")

        elif choice == "3":
            pass_fail = identify_pass_fail(students)
            print("Students who passed:", pass_fail["passed"])
            print("Students who failed:", pass_fail["failed"])

        elif choice == "4":
            top_performer = find_top_performer(students)
            print(f"Top performer: {top_performer}")

        elif choice == "5":
            display_students(students)

        elif choice == "6":
            print("Exiting the system.")
            break

        else:
            print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
