# School Performance Analysis System

## Overview
The School Performance Analysis System is designed to manage and analyze student performance in key subjects: Math, Science, and English. This system allows educators to track student grades, calculate averages, identify top performers, and determine which students may need additional support.

## Project Structure
```
school-performance-analysis
├── src
│   ├── main.py               # Entry point for the application
│   ├── student_operations.py  # Functions to manage student records
│   └── utils
│       └── __init__.py       # Utility functions and constants
├── requirements.txt           # List of dependencies
└── README.md                  # Project documentation
```

## Setup Instructions
1. Clone the repository to your local machine.
2. Navigate to the project directory.
3. Install the required packages using the following command:
   ```
   pip install -r requirements.txt
   ```

## Usage
1. Run the application by executing the `main.py` file:
   ```
   python src/main.py
   ```
2. Follow the on-screen menu to perform various operations such as:
   - Adding students
   - Calculating average marks
   - Identifying students who passed or failed
   - Finding the top performer
   - Displaying all student records in alphabetical order

## Contributing
Contributions are welcome! Please feel free to submit a pull request or open an issue for any enhancements or bug fixes.

## License
This project is licensed under the MIT License. See the LICENSE file for more details.